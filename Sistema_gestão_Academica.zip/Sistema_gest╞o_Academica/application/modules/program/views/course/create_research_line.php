<?php

createResearchLineForm($courses);

echo "<a href='javascript:history.go(-1)' class='btn btn-danger'>Voltar</a>";