<?php

$config = [
  'selection_process_subscription'
    => include(MODULESPATH.'/program/form_validations/SelectionProcessSubscriptionValidation.php')
];

return $config;

?>
