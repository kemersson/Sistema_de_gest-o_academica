<?php defined('BASEPATH') OR exit('No direct script access allowed');

require_once(MODULESPATH."/secretary/constants/DocumentConstants.php");

$lang[DocumentConstants::REQUEST_OPEN] = 'Aberta';
$lang[DocumentConstants::REQUEST_READY] = 'Pronto';
$lang[DocumentConstants::REQUEST_READY_ONLINE] = 'Pronto Online';