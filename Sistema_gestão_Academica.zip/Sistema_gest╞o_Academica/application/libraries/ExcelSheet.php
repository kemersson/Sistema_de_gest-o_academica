<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class ExcelSheet extends PHPExcel{

    public function __construct() {
        parent::__construct();
    }
}