
<br>
<br>
<div class="col-lg-12 col-xs-6">
	<div class="small-box bg-blue">
		<div class="inner">
		    <h2 align="center">Bem vindo a página de Coordenador!</h2>
		   
			<div class = "row">
				<div class="col-lg-6">
				    <p>
					    <div class="list-group" align='center'>
							<?php echo anchor('program/coordinator/coordinator_programs', "Avaliação de programas", "class='list-group-item' style='width:70%;'");?>
							<?php echo anchor('program/coordinator/manageDimensions', "Dimensões de avaliação", "class='list-group-item' style='width:70%;'");?>
						</div>
		        	</p>
			    </div>
			</div>
 			<div class="icon">
		    	<i class="fa fa-user"></i>
			</div>
		</div>
	</div>
</div>