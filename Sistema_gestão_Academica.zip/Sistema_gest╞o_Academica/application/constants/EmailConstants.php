<?php
require_once('Constants.php');

class EmailConstants extends Constants{

	const SENDER_NAME = "SiGA";
    const SENDER_EMAIL = "no-reply-sip@il.unb.br";
}