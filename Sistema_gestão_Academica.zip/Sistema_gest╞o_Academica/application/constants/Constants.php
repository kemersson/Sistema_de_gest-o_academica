<?php

/**
 * This class contain methods to handle system constants
 * All constants classes of each sector of the system must extend this class
 */

abstract class Constants{
	

}

