<?php

class ExpenseNatureConstants{

	const DEFAULT_STATUS = "default";
	const ACTIVE = "active";
	const INACTIVE = "inactive";

	const ACTIVE_INVERSE = "inactive";
	const INACTIVE_INVERSE = "active";

	const EXPENSE_NATURE_SUCCESS = "Natureza de despesa criada com sucesso.";
	const EXPENSE_NATURE_FAIL = "Não foi possível criar a natureza de despesa.";

}