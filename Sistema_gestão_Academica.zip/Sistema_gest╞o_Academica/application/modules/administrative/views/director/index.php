<h2 class="principal">Bem vindo a página de Diretor !</h2>

<div class="callout callout-info">
	<h4><i class="fa fa-arrow-left"></i> Navegue no menu lateral para acessar as funcionalidades de diretor.</h4>
</div>