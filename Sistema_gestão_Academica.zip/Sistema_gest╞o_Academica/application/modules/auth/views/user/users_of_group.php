<?php 
	displayUsersOfGroup($idGroup, $usersOfGroup);

	echo "<br>";
	echo anchor('user_report', "Voltar", "class='btn btn-danger'");
?>