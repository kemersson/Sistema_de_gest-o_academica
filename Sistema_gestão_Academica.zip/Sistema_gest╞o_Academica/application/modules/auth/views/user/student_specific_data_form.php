<?php

echo "<br>";
echo "<br>";
displayStudentSpecificDataPage($userData->getId());

echo "<br>";
echo "<br>";

displayFormUpdateStudentBasicInformation($userData->getId());