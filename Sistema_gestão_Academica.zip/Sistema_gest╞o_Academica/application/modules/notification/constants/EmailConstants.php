<?php

class EmailConstants {

	const SENDER_NAME = "SiGA";
    const SENDER_EMAIL = "no-reply-sip@il.unb.br";
}