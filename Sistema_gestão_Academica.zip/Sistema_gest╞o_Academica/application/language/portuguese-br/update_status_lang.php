<?php defined('BASEPATH') OR exit('No direct script access allowed');

require_once(MODULESPATH."/finantial/constants/ExpenseNatureConstants.php");

$lang['toButton'.ExpenseNatureConstants::ACTIVE] = 'Desativar';
$lang['toButton'.ExpenseNatureConstants::INACTIVE] = 'Ativar';

$lang['toMessage'.ExpenseNatureConstants::ACTIVE] = 'ativada';
$lang['toMessage'.ExpenseNatureConstants::INACTIVE] = 'desativada';