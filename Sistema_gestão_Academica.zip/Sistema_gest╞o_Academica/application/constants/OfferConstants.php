<?php

require_once('Constants.php');

class OfferConstants extends Constants{

    const APPROVED_OFFER = "approved";
    const PROPOSED_OFFER = "proposed";
    const PLANNED_OFFER = "planned";
}