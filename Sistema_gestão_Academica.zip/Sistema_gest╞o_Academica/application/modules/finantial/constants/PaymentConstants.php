<?php

class PaymentConstants{

	const MAX_INSTALLMENTS = 5;
	const MAX_TOTAL_VALUE = 8000;
}