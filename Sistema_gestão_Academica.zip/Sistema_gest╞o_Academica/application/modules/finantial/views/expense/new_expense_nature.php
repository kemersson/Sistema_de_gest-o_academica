<h2 class="principal">Nova Natureza de Despesa</h2>

<div class="form-box"> 
	<div class="header">
		Cadastrar natureza de despesa 
	</div>
		<?= form_open("new_expense_nature") ?>
    	<div class="body bg-gray">
        <?php include '_form_expense_nature.php' ?>
</div>